import java.util.ArrayList;
import java.util.List;

/**
 * Classe qui permettra � l'utilisateur de selectionner en fonction du rang de l'individu
 * @author Anthony Bonnefois
 */

public class RankSelection extends Select
{
	public RankSelection()
	{
	}
	
	/**
	 * Methode selection qui trie la population en fonction de son poids et retourne les n meilleurs
	 * @return Une liste d'individus
	 */
	@Override
	public  List<Individu> Selection(Population pop , int nb_selected_parents)
	{
		List<Individu> list_parents = new ArrayList<Individu>();
		
		for(int j = 0; j < nb_selected_parents; j++)
			list_parents.add(pop.GetPopulation().get(j));

		return list_parents;
	}

}
