import java.util.List;

/**
 * Classe abstraite qui permettra � l'utilisateur de choisir un type de Selection (design patern Strategy)
 * @author Anthony Bonnefois
 */
public abstract class Select 
{
	public abstract List<Individu> Selection(Population pop, int nb_parent_selected);
}
