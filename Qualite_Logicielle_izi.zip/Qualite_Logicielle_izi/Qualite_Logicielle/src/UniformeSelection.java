import java.util.ArrayList;
import java.util.List;

/**
 * Classe qui permettra � l'utilisateur de selectionner en fonction de l'uniformit� de l'individu
 * @author Anthony Bonnefois
 */

public class UniformeSelection extends  Select
{
	/**
	 * Methode qui retourne n individus aleatoirement � partir de la liste d'individu
	 * @return Une liste d'individus
	 */
	@Override
	public  List<Individu> Selection(Population pop,  int nb_parent_selected )
	{
		// Declaration d'une liste d'individus
		ArrayList<Individu> _pop = new ArrayList<Individu>();
		
		// Affectation des individus � la liste
		for(int i = 0; i < pop.GetSizePop(); i++)
			_pop.add(pop.GetPopulation().get(i));

		List<Individu> list_parents = new ArrayList<Individu>();

		for(int j = 0; j < nb_parent_selected; j++)
		{
			int randomId = (int) (Math.random() * _pop.size());

			list_parents.add(_pop.get(randomId));
			_pop.remove(randomId);
		}
		
		return list_parents;
	}
}