import java.util.ArrayList;
import java.util.List;

/**
 * Classe qui permettra � l'utilisateur de selectionner en fonction du rang de l'individu
 * @author Anthony Bonnefois
 */
public class TournamentSelection extends Select
{	
	/**
	 * Methode qui retourne n individus en les ayant selectionn�s avec la methode tournement
	 * @return Une liste d'individus
	 */
	@Override
	public  List<Individu> Selection(Population pop,  int nb_parent_selected )
	{
		ArrayList<Individu> _pop = new ArrayList<Individu>();
		_pop = pop.GetPopulation();
		
		List<Individu> list_parents = new ArrayList<Individu>();
		
		for(int i = 0; i < nb_parent_selected; i++)
		{
			// On choisit 3 individus parmi la liste
			int randomId = (int) (Math.random() * _pop.size());
			int randomId2 = (int) (Math.random() * _pop.size());
			int randomId3 = (int) (Math.random() * _pop.size());
			
			// On ne retient que le meilleur
			int max = Math.max(randomId,randomId2);
			int max2 = Math.max(randomId3,randomId2);
			max2 = Math.max(max,max2);
			
			list_parents.add(_pop.get(max2));			
		}
		return list_parents;
	}
}
