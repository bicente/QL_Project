import java.awt.List;
import java.util.ArrayList;

/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Vincent GRUEL
 */
public class Evaluate
{
	int i=0;
	int toRecul=0;
	private Population _population;
	private String _function;
	//Ajouter la fonction math�matique qu'on doit optimiser
	
	/**
	 * Constructeur d'un objet de type �valuation
	 * @return Pas de valeur de retour
	 */
	Evaluate(Population population, String function)//Ajouter un objet de type fonction mono-objectif dans le constructeur
	{
		_population=population;
		_function=function;
		
	}
	
	/**
	 * Cr�ation de 4 Threads pour �valuer le poids de 4 individus de la population simultan�ment
	 * @return Pas de valeur de retour
	 */
	public ArrayList<Individu> EvaluateAllIndiv()
	{
		for(i=0; i<_population.GetSizePop(); i=i+4)
		{
			int k=i;
			ArrayList<ThreadEvaluate> _listeThread=new ArrayList<ThreadEvaluate>();
			for(int j=0;j<4;j++)
			{
				_listeThread.add(new ThreadEvaluate(_population.GetIndiv(i), _function));
			}
			for(ThreadEvaluate t : _listeThread)
			{
				t.start();
			}
			for(ThreadEvaluate t : _listeThread)
			{
				_population.SetIndiv(k, t.GetPoids());
				k++;
			}
			//On teste la valeur de i pour bien �valuer tous les individus quitte � �valuer au maximum 3 individus 2 fois
			if(i+4>_population.GetSizePop())
			{
				int diff=0;
				diff=_population.GetSizePop()-i;
				toRecul=4-diff;
				i=i-toRecul;
			}
		}
		return _population.GetPop();
	}
}
