public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Algorithme al = new Algorithme(2,"test", 0, 10);
		

	}

}
