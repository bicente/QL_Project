/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Thibault POULHALEC
 */
public class Individu 
{
	private Genome _genome;
	private double _poids;
	private int size=0;
	private static final double uniformRate=0.5;
	private static final double mutationRate=0.03;
	private int competence;
	
	Individu()
	{
		/** Creation individu
		* Appel de la fonction de cr�ation des individus rentr�e par l'utilisateur
		*/
	}
	
	/**
	 * Fonction qui retourne un g�nome pour calcul du poids dans la fonction d'�valuation
	 * @return Un objet de type G�nome aussi consid�r� comme �tant une solution possible du probl�me (coordonn�es X et Y)
	 */
	public double[] GetGenome()
	{
		double ParamGenome[]= new double[_genome.GetSize()];
		for(int i=0; i<_genome.GetSize();i++)
		{
			ParamGenome[i]=_genome.GetGenome(i);
		}
		return ParamGenome;
	}
	
	public double GetGenomeIdx(int idx)
	{
		double ParamGenome= 0;
		ParamGenome=_genome.GetGenome(idx);
		return ParamGenome;
	}
	
	public void SetGenome(int idx, double value)
	{
		_genome.SetGenome(idx,value);
	}
	/**
	 * Fonction qui permet d'affecter le poids de l'individu
	 * @return Pas de valeur de retour
	 */
	public void SetPoids(double poids)
	{
		_poids=poids;
	}
	
	/**
	 * R�cup�ration du poids d'un individu
	 * @return Le poids de l'individu
	 */
	public double GetPoids()
	{
		return _poids;
	}
	
	/**
	 * Fonction qui permet de muter un individu
	 * @return un Individu mut� ou non
	 */
	public Individu Mutate(Individu indiv, double rate)
	{
		double _mutationrate = mutationRate;
		if(rate != 0 && rate <= 0 && rate >= 100)
			_mutationrate = rate;
			
		if (Math.random() <= _mutationrate)
		{
			// Create random gene
			byte gene = (byte) Math.round(Math.random());
			indiv.SetPoids(gene);
		}
		return indiv;
	}
	
	/**
	 * Fonction qui permet de croiser deux individus
	 * @return un Individu crois�
	 */
	public Individu CrossOver(Individu indiv1, Individu indiv2)
	{
		Individu enfant = new Individu();
		for (int i = 0; i < indiv1.GetGenome().length; i++)
		{
            // Crossover
            if (Math.random() <= uniformRate)
            {
            	enfant.SetGenome(i, indiv1.GetGenomeIdx(i));
            } 
            else
            {
            	enfant.SetGenome(i, indiv2.GetGenomeIdx(i));
            }
        }
		return enfant;
	}
}
