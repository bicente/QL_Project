import java.util.ArrayList;
import java.util.List;

import src.org.mariuszgromada.math.mxparser.*;
/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Anthony BONNEFOIS
 */
public class Algorithme 
{
	private Population _population;
	private Evaluate _evaluation;
	private String _function="";
	
	Algorithme(int size, String function, int xmin, int xmax)//Il faut mettre la taille de la population, la fonction, le m�thode de s�l�ction, les crit�res d'arr�t
	{
		_function=function;
		
		//Cr�ation de la population
		_population=new Population(30, 0, 10);

		//�valuation de la population
		_evaluation=new Evaluate(_population, _function);
		_population.SetPopulation(_evaluation.EvaluateAllIndiv());
		
		//Selection 
		String choixSelection ="Aleatoire";
		Select rang;
		switch (choixSelection) {
	    case "Rang":  rang= new RangSelection();
	             break;        
	    case "Tournois": rang= new TourneeSelection();
	    		break;
	    case "Aleatoire": rang = new UniformeSelection();
				break;
	    default: rang= new RangSelection();
	    break;
	             
		}
		List<Individu> list_parent_selected = new ArrayList<Individu>();

		 list_parent_selected= rang.Selection(_population,5);
		 

		 for(int i=0;i<list_parent_selected.size();i++)
		 {
			 System.out.println("meilleur" +i+ "="+	list_parent_selected.get(i).GetPoids()+"\n");
			
		 }
		 //Croisement	
		 //Mutation
	}
}
