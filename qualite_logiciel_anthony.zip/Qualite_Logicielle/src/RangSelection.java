import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RangSelection extends Select
{
	/**
	 * Constructeur de la m�thode de selection
	 * @param pop
	 * @param ind
	 */
	public RangSelection()
	{

	}
	
	/**
	 * Methode selection qui trie la population en fonction de son poids et retourn les n meilleur
	 * @parm pop population
	 * @param nb_parent_selected nombre choisit de parent par l'utilisateur
	 * @return List<Individu>
	 */
	@Override
	public  List<Individu> Selection(Population pop , int nb_parent_selected)
	{
		
		List<Individu> liste_parents=new ArrayList<Individu>();
		for(int j = 0; j < nb_parent_selected; j++)
		{
			liste_parents.add(pop.GetPopulation().get(j));
		}
		return liste_parents;
	}

}
