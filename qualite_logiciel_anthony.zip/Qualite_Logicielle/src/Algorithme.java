import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

//import src.org.mariuszgromada.math.mxparser.*;
/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Anthony BONNEFOIS
 */
public class Algorithme 
{
	//private Population _population;
	private Evaluate _evaluate;
	private String _function="";
	private double _mutation_rate = 0.03;
	private int nb_enfant_cree = 5;

	/**
	 * Algorithme de traitement qui retourne la solution optimale a notre fonction
	 * @param size
	 * @param function
	 * @param xmin
	 * @param xmax
	 */
	Algorithme(int size, String function, int xmin, int xmax)//Il faut mettre la taille de la population, la fonction, le m�thode de s�l�ction, les crit�res d'arr�t
	{
		_function=function;

		// Cr�ation de la population
		Population _population=new Population(30, 0, 10);

		// Cr�ation du critere d'arret
		Critere_arret crt_arret = new Critere_arret(_population,Best_individu(_population));
		
		// Variable pour la gestion du crit�re d'arr�t
		long time = System.nanoTime();
		boolean stop = false;

		// -- Selection du type d'arret souhait� -- \\
		String choixSelection ="Rang";
		Select rang;

		switch (choixSelection)
		{
			case "Rang":  rang = new RangSelection();
			break;        
			case "Tournois": rang = new TourneeSelection();
			break;
			case "Aleatoire": rang = new UniformeSelection();
			break;
			default: rang = new RangSelection();
			break;
		}

		// Cr�ation de la liste d'individus qui seront crois�s et mut�s
		List<Individu> list_parent_selected = new ArrayList<Individu>();
		
		// -- �valuation de la population -- \\
		//_evaluate=new Evaluate(_population, _function);
		//_population.SetPopulation(_evaluate.EvaluateAllIndiv());
		
		//generation du poid si evaluation ne fonctionne pas
		for(int i=0; i< _population.GetSizePop();i++)
		{
			_population.GetPopulation().get(i).SetPoids(Math.random()*5);;
		}
		do
		{
			//trie des elements de la liste par ordre decroissant de leur poids
			ArrayList<Individu> _pop_intermediaire=new ArrayList<Individu>();
			_pop_intermediaire = _population.GetPopulation();
			Collections.sort(_pop_intermediaire, new Sortbyroll()); 	
			_population.SetPopulation(_pop_intermediaire);
			
			//selection des parents pour cr�er les nb enfant
			list_parent_selected= rang.Selection(_population,nb_enfant_cree+1);
			
			// Cr�ation d'une liste d'individu qui contient les enfant
			List<Individu> list_child_crossed = new ArrayList<Individu>();

			// -- Croisement -- \\

			// Croise l'�l�ment de la liste i avec celui d'apr�s et ajoute l'individu cr�� � la liste d'individus crois�s
			for(int i = 0; i < list_parent_selected.size(); i++)
			{
				if(i<list_parent_selected.size()-1)
				{
					list_child_crossed.add(CrossOver.crossOver(list_parent_selected.get(i), list_parent_selected.get(i + 1)));
				}
			}
				
			// -- Mutation -- \\
			
			// R�affecte l'individu i potentiellement mut� � la population, � la place de l'individu i non mut�
			for(int i=0; i < list_child_crossed.size(); i++)
			{
				list_child_crossed.set(i, Mutate.mutate(list_child_crossed.get(i), _mutation_rate));
			}
			
			//creation de la population d'enfant
			Population _list_enfant=new Population(nb_enfant_cree, 0, 10);

			for(int i=0; i<nb_enfant_cree;i++)
			{
				_list_enfant.SetIndiv(i, list_child_crossed.get(i));
				
				// -- �valuation de la population d'enfant-- \\
				///	_evaluate=new Evaluate(_list_enfant, _function);
				//	_list_enfant.SetPopulation(_evaluate.EvaluateAllIndiv());
				
				//generation du poid si evaluation ne fonctionne pas
				_list_enfant.GetPopulation().get(i).SetPoids(Math.random()*5);
			}

			
			//Selection de la methode de remplacement des parent par les enfants
			String _choix_methode_remplacement ="meilleur individu";

			switch (_choix_methode_remplacement) 
			{
				case "meilleur individu": 

					for(int i=0;i<_list_enfant.GetSizePop();i++)
					{
						for(int j=0; j<_population.GetSizePop();j++)
						{
							if(_list_enfant.GetPopulation().get(i).GetPoids()>_population.GetPopulation().get(j).GetPoids())
							{
								for(int k=_population.GetSizePop()-1;k>j;k--)
								{
									_population.SetIndiv(k, _population.GetPopulation().get(k-1));	
								}
								_population.SetIndiv(j, _list_enfant.GetPopulation().get(i));
								break;
							}
						}
					}
					
				break;        
				case "aleatoire": 
					int randomId = 1;
					for(int i=0;i<_list_enfant.GetSizePop();i++)
					{		
							do
							{
								randomId = (int) (Math.random() * _population.GetSizePop());
							}while(randomId==0);
							
							_population.SetIndiv(randomId, _list_enfant.GetPopulation().get(i));
					}
				break;
				default: 
					for(int i=0;i<_list_enfant.GetSizePop();i++)
					{
						for(int j=0; j<_population.GetSizePop();j++)
						{
							if(_list_enfant.GetPopulation().get(i).GetPoids()>_population.GetPopulation().get(j).GetPoids())
							{
								for(int k=_population.GetSizePop()-1;k>j;k--)
								{
									_population.SetIndiv(k, _population.GetPopulation().get(k-1));	
								}
								_population.SetIndiv(j, _list_enfant.GetPopulation().get(i));
								break;
							}
						}
					}
				break; 
			}
			
			// -- Choix du critere arret -- \\
			Individu best_indiv = Best_individu(_population);
			
			String _choix_crt_arret ="stop_individu_meilleur";
			switch (_choix_crt_arret) 
			{
				case "Temps": stop= crt_arret.stop_time(time,10);
				break;        
				case "X iteration": stop= crt_arret.stop_Xiteration(100);
				break;
				case "population similaire": stop= crt_arret.stop_population_evolution(_population, 5);		
				break;
				case "meilleur individu": stop= crt_arret.stop_individu_meilleur(best_indiv, 5);
				break;
				default: stop= crt_arret.stop_individu_meilleur(best_indiv, 20);
				break; 
			}
		}while(stop == false);
	}

	/**
	 * 
	 * Fonction qui permet de r�cup�rer le meilleur individu de la population
	 * @return le meilleur individu
	 */
	public Individu Best_individu(Population pop)
	{
		int index = 0;

		for(int i = 0; i < pop.GetPopulation().size(); i++)
		{
			if(pop.GetPopulation().get(i).GetPoids() > pop.GetPopulation().get(index).GetPoids())
				index = i;
		}
		return pop.GetPopulation().get(index);
	}
}
