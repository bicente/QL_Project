public class StopCondition_BestIndividu  implements IStopCondition
{
	/**
	 * Arr�t si le meilleur individu a �t� trouv�
	 * @return
	 */
	int _nb_best_iteration =0;
	Individu _ind;
	boolean first = false;
	
	@Override
	public boolean stop_condition(Individu ind, int nb_iteration)
	{
		if (first == true)
		{
			if(ind == _ind)
				_nb_best_iteration += 1;
			else
			{
				_ind = ind;
				_nb_best_iteration=0;
			}
			
			if(_nb_best_iteration >= nb_iteration)
				return true;
			else
				return false;
		}
		else
		{
			_ind = ind;
			first = true;
			return false;
		}
	}

}
