public class StopCondition_Xiteration  implements IStopCondition
{
	int _nb_Xiteration = 0;
	
	@Override
	/**
	 * Arr�t apr�s un nombre donn� d'it�rations
	 * @return vrai si nombre iteration r�aliser sinon retourn faux
	 */
	public boolean stop_condition(int X_iteration)
	{
		if(_nb_Xiteration >= X_iteration)
			return true;
		
		else
		{
			_nb_Xiteration += 1;
			System.out.println("nb_Xiteration= " + _nb_Xiteration);
			return false;
		}
	}
}
