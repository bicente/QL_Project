import java.util.ArrayList;

public class Main
{
	public static void main(String[] args) 
	{		
		String function = "F(x,y) = (x + 2*y - 7)^2 + (2*x + y - 5)^2";
		int sizeGenome = 2;
		int xmin = -10;
		int xmax = 10;
		int nbChildren = 20;
		int populationSize = 100;
		
		/**
		 * S�lection de la methode de r�incorporation des enfants dans la population
		 * Il faut choisir un param�tre parmi les deux suivants :
		 * Worst individu = On remplace les pires individus de la population
		 * Random = On remplace al�atoirement des individus de la population (sauf le meilleur)
		 */
		String replacement_method = "Worst individu";
		
		/** 
		 * S�lection des conditions d'arret
		 * Il est possible de choisir plusieurs arguments parmi la liste suivante :
		 * Best individu = Si le meilleur individu de la population est le m�me sur 5 it�rations de suite
		 * Same Population = Si toute la population est la m�me sur 5 it�rations de suite
		 * Time = Au bout d'un certain temps
		 * X iterations = Apr�s X it�rations
		 */
		ArrayList<String> list_stop_condition = new ArrayList<>(); 
		list_stop_condition.add("Best individu");
		list_stop_condition.add("X iterations");
		
		/**
		 * Methode de s�lection des parents pour le croisement
		 * Il faut choisir un param�tre parmi les trois suivants :
		 * Rank = On choisit les meilleurs parents
		 * Random = On choisit les parents al�atoirements
		 * Tournament = On s�lectionne trois parents al�atoirement et on choisit le meilleur
		 */
		String selection_method = "Rank";
		
		Algorithm al = new Algorithm(function, sizeGenome, xmin, xmax, nbChildren, populationSize,
										replacement_method, list_stop_condition, selection_method);
	}
}
