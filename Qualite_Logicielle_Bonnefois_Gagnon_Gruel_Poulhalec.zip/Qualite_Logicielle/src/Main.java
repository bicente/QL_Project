import java.util.ArrayList;

public class Main
{
	public static void main(String[] args) 
	{		
		String function = "F(x,y) = (x + 2*y - 7)^2 + (2*x + y - 5)^2"; // Le r�sultat attendu est d'environ (1 ; 3)
		// String function = "F(x,y) = 0.26*(x^2 + y^2) - 0.48*x*y"; // Le r�sultat attendu est d'environ (0 ; 0)
		// String function = "F(x) = x^2"; // Le r�sultat attendu est (0)
		int sizeGenome = 2;
		int xmin = -10;
		int xmax = 10;
		int nbChildren = 20;
		int populationSize = 100;
		
		/**
		 * S�lection de la methode de r�incorporation des enfants dans la population
		 * Il faut choisir un param�tre parmi les deux suivants :
		 * Worst individu = On remplace les pires individus de la population
		 * Random = On remplace al�atoirement des individus de la population (sauf le meilleur)
		 */
		String replacement_method = "Worst individu";
		
		/** 
		 * S�lection des conditions d'arret
		 * Il est possible de choisir plusieurs arguments parmi la liste suivante :
		 * Best individu = Si le meilleur individu de la population est le m�me sur 5 it�rations de suite
		 * Same population = Si toute la population est la m�me sur 5 it�rations de suite
		 * Time = Au bout d'un certain temps
		 * X iterations = Apr�s X it�rations
		 */
		ArrayList<String> list_stop_condition = new ArrayList<>(); 
		list_stop_condition.add("Best individu");
		list_stop_condition.add("X iterations");
		
		/**
		 * Liste des param�tres de chaque crit�re d'arret
		 * Le premier �l�ment est pour Time. 5000 est une bonne valeur
		 * Le deuxi�me �l�ment est pour X iterations. 100 est une bonne valeur
		 * Le troisi�me �l�ment est pour Same population. 5 est une bonne valeur
		 * Le quatri�me �l�ment est pour Best individu. 10 est une bonne valeur
		 */
		int[] list_stop_parameters = {5000, 100, 5, 10};
		
		/**
		 * Methode de s�lection des parents pour le croisement
		 * Il faut choisir un param�tre parmi les trois suivants :
		 * Rank = On choisit les meilleurs parents
		 * Random = On choisit les parents al�atoirements
		 * Tournament = On s�lectionne trois parents al�atoirement et on choisit le meilleur
		 */
		String selection_method = "Rank";
		
		Algorithm al = new Algorithm(function, sizeGenome, xmin, xmax, nbChildren, populationSize,
										replacement_method, list_stop_condition, list_stop_parameters, selection_method);
	}
}
