public interface IStopCondition
{
	public default boolean stop_condition(int X_iteration)
	{
		return false;
	}
	
	public default boolean stop_condition(long time, int  partie_int)
	{
			return false;
	}
	
	public default boolean stop_condition(Population pop, int nb_iteration )
	{
		return false;
	}
	
	public default boolean stop_condition(Individu best_individu, int nb_iteration )
	{
		return false;
	}
}
