public class StopConditionFactory
{
	public IStopCondition getStopCondition(String stopcondition)
	{
		switch (stopcondition) 
		{     
			case "X iterations":
				return new StopCondition_Xiteration();
			case "Time":
				return new StopConditionTime();
			case "Same Population" :
				return new StopCondition_BestPopulation();
			case "Best individu" :
				return new StopCondition_BestIndividu();
			default: 
				return new StopCondition_Xiteration();
		}
	}
}
