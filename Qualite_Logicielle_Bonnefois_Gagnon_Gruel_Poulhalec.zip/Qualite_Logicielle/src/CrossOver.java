import java.math.BigDecimal;

/**
 * Classe qui permet de croiser deux individus
 * @author Adrien Gagnon et Thibault Poulhalec
 */
public class CrossOver
{
	public CrossOver() {	}

	/**
	 * Fonction qui permet de croiser deux individus
	 * @return un Individu crois�
	 */
	public static Individu crossOver(Individu parent1, Individu parent2)
	{
		Individu child = new Individu();
		for (int i = 0; i < parent1.GetGenome().length; i++)
		{
			double param = 0;
			double genomeP1 = 0;
			double genomeP2 = 0;
			genomeP1 = parent1.GetGenomeIdx(i);
			genomeP2 = parent2.GetGenomeIdx(i);
			param = (genomeP1 + genomeP2) /2;
			BigDecimal bd = new BigDecimal(param);
			bd = bd.setScale(3,BigDecimal.ROUND_DOWN);
			param = bd.doubleValue();
			child.SetGenome(i, param);
		}
		return child;
	}
}