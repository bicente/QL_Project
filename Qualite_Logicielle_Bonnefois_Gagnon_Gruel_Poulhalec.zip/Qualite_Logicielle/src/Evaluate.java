import java.util.ArrayList;

/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Vincent GRUEL
 */
public class Evaluate
{
	int i = 0;
	private Population _population;
	private String _function;
	
	/**
	 * Constructeur d'un objet de type �valuation
	 * @return Pas de valeur de retour
	 */
	Evaluate(Population population, String function)
	{
		_population = population;
		_function = function;
	}
	
	/**
	 * Cr�ation de 4 Threads pour �valuer le poids de 4 individus de la population simultan�ment
	 * @return Pas de valeur de retour
	 */
	public ArrayList<Individu> EvaluateAllIndiv()
	{
		// On boucle jusqu'� avoir �valu� l'int�gralit� de la population
		for(int i = 0; i < _population.GetSizePop(); i = i+4)
		{
			int k=i;
			// Cr�ation d'une liste de thread et remplissage de celle-ci
			ArrayList<ThreadEvaluate> _listThread=new ArrayList<ThreadEvaluate>();
			for(int j = 0; j < 4; j++)
			{
				if(i + j < _population.GetSizePop())
					_listThread.add(new ThreadEvaluate(_population.GetIndiv(i + j), _function));
			}
			
			// Lancement des threads
			for(ThreadEvaluate t : _listThread)
			{
				try
				{
					t.start();
					//On attend que le thread soit termin� pour lancer le suivant
					t.join();
				}
				catch(InterruptedException e)
				{
				}
			}
			
			// R�cup�ration des diff�rents poids pour les affecter aux individus
			for(ThreadEvaluate t : _listThread)
			{
				Individu newIndiv = new Individu();
				newIndiv = _population.GetIndiv(k);
				newIndiv.SetPoids(t.GetPoids());
				_population.SetIndiv(k, newIndiv);
				k++;
			}
		}
		// On renvoie la population actualis�e avec les poids
		return _population.GetPopulation();
	}
	
	public void SetEvaluate(Population pop)
	{
		_population = pop;
	}
}
