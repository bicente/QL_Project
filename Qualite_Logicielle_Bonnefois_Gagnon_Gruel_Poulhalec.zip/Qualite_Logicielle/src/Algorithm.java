import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Anthony BONNEFOIS
 */
public class Algorithm 
{
	private Evaluate _evaluate;
	private String _function="";
	private double _mutation_rate = 0.03;
	private int _nb_created_children = 20;
	private int _sizepopulation =100;
	private double[] Bestgenome;
	private String _replacement_methode_choice ="Best individu";
	private List<String> _list_condition_arret;
	private String _choixSelection ="Rank";

	/**
	 * Algorithme de traitement qui retourne la solution optimale a notre fonction
	 * Il faut mettre la taille de la population, la fonction, le m�thode de s�l�ction, les crit�res d'arr�t
	 */
	Algorithm(String function, int SizeGenome, int xmin, int xmax, int nb_created_children, int sizepopulation,
				String replacement_methode_choice, List<String> list_condition_arret, String choixSelection )
	{
		_function = function;
		_nb_created_children = nb_created_children;
		_list_condition_arret = list_condition_arret;
		_sizepopulation = sizepopulation;
		_replacement_methode_choice = replacement_methode_choice;
		_choixSelection = choixSelection;
		
		Individu  best_indiv;
		
		// Cr�ation de la population
		Population population = new Population(_sizepopulation, SizeGenome, xmin, xmax);
		 
		// -- Selection du type d'arret souhait� -- \\
		Select rank;

		switch (_choixSelection)
		{
			case "Rank":
				rank = new RankSelection();
			break; 
			
			case "Tournament":
				rank = new TournamentSelection();
			break;
			
			case "Random":
				rank = new UniformeSelection();
			break;
			
			default:
				rank = new RankSelection();
			break;
		}

		// Cr�ation de la liste d'individus qui seront crois�s et mut�s
		List<Individu> list_selected_parent = new ArrayList<Individu>();
		
		// -- �valuation de la population -- \\
		_evaluate = new Evaluate(population, _function);
		population.SetPopulation(_evaluate.EvaluateAllIndiv());
		
		List<StopConditionFactory> _stopFactory = new ArrayList<>();
		List<IStopCondition> _stopCondition = new ArrayList<>();
		List<Boolean> _listStop = new ArrayList<>(); 
		
		boolean stop = false;
		
		StopConditionFactory _factory = new StopConditionFactory();
		String _condition = "";
		
		for(int i = 0; i < _list_condition_arret.size(); i++)
		{
			_listStop.add(stop);
			_stopFactory.add(new StopConditionFactory());
			_factory = _stopFactory.get(i);
			_condition = _list_condition_arret.get(i);
			
			_stopCondition.add(_factory.getStopCondition(_condition));
		}
		
		boolean stop_final = false;
		
		do
		{
			// Trie les elements de la liste par ordre decroissant en fonction de leur poids
			ArrayList<Individu> _intermediate_pop = new ArrayList<Individu>();
			_intermediate_pop = population.GetPopulation();
			Collections.sort(_intermediate_pop, new Sortbyroll()); 	
			population.SetPopulation(_intermediate_pop);

			// Selection des parents pour cr�er les nb enfant
			list_selected_parent = rank.Selection(population, _nb_created_children + 1);
			
			// Cr�ation d'une liste d'individu qui contient les enfant
			List<Individu> list_crossed_children = new ArrayList<Individu>();

			// -- Croisement -- \\
			Random r = new Random();
			Individu parent1 = new Individu();
			Individu parent2 = new Individu();
			Individu crossed_indiv = new Individu();

			// Croise l'�l�ment de la liste i avec celui d'apr�s et ajoute l'individu cr�� � la liste d'individus crois�s
			for(int i = 0; i < list_selected_parent.size() - 1; i++)
			{
				parent1 = list_selected_parent.get(r.nextInt(list_selected_parent.size()));
				parent2 = list_selected_parent.get(r.nextInt(list_selected_parent.size()));
				crossed_indiv = CrossOver.crossOver(parent1, parent2);
				list_crossed_children.add(crossed_indiv);
			}
			
			// -- Mutation -- \\
			
			// R�affecte l'individu i potentiellement mut� � la population, � la place de l'individu i non mut�
			for(int i = 0; i < list_crossed_children.size(); i++)
				list_crossed_children.set(i, Mutate.mutate(list_crossed_children.get(i), _mutation_rate));

			// Creation de la population d'enfant
			Population list_children = new Population(nb_created_children, SizeGenome, xmin, xmax);

			for(int i=0; i < nb_created_children; i++)
				list_children.SetIndiv(i, list_crossed_children.get(i));
			
			// -- �valuation de la population d'enfant-- \\
			_evaluate.SetEvaluate(list_children);
			list_children.SetPopulation(_evaluate.EvaluateAllIndiv());
			
			// Selection de la methode de remplacement des parents par les enfants
			Individu indiv_i = new Individu();
			Individu indiv_j = new Individu();
			
			switch (_replacement_methode_choice) 
			{
				case "Worst individu": 
					for(int i = 0; i < list_children.GetSizePop(); i++)
					{
						for(int j = 0; j < population.GetSizePop(); j++)
						{
							indiv_i = list_children.GetIndiv(i);
							indiv_j = population.GetIndiv(j);
							
							if(indiv_i.GetPoids() < indiv_j.GetPoids())
							{
								for(int k = population.GetSizePop() - 1;k > j; k--)
									population.SetIndiv(k, population.GetIndiv(k-1));	
								
								population.SetIndiv(j, indiv_i);
								break;
							}
						}
					}
					
				break;
				
				case "Random": 
					int randomId = 1;
					for(int i = 0; i < list_children.GetSizePop(); i++)
					{		
						// On s�lectionne al�atoirement un individu de la population (sauf le meilleur)
						do
						{
							randomId = (int) (Math.random() * population.GetSizePop());
						}while(randomId == 0);
							
						indiv_i = list_children.GetIndiv(i);
						population.SetIndiv(randomId, indiv_i);
					}
				break;
				
				default: 
					for(int i = 0; i < list_children.GetSizePop(); i++)
					{
						for(int j = 0; j < population.GetSizePop(); j++)
						{
							indiv_i = list_children.GetIndiv(i);
							indiv_j = population.GetIndiv(j);
							if(indiv_i.GetPoids() < indiv_j.GetPoids())
							{

								for(int k = population.GetSizePop() - 1; k > j; k--)
									population.SetIndiv(k, population.GetIndiv(k-1));	
								
								population.SetIndiv(j, indiv_i);
								break;
							}
						}
					}
				break; 
			}
			
			// Variables pour la gestion du crit�re d'arr�t
			long time = System.nanoTime();
			
			for(int i = 0; i < _list_condition_arret.size(); i++)
			{
				IStopCondition _iStopCondition = _stopCondition.get(i);
				switch (_list_condition_arret.get(i)) 
				{
				
					case "Time":
						_listStop.set(i, _iStopCondition.stop_condition(time,5000));
					break;     
						
					case "X iterations":
						_listStop.set(i, _iStopCondition.stop_condition(100));
					break;
						
					case "Same Population":
						_listStop.set(i, _iStopCondition.stop_condition(population,5));		
					break;
						
					case "Best individu": 
						best_indiv = Best_individu(population);
						_listStop.set(i, _iStopCondition.stop_condition(best_indiv,50));
					break;
					
					default: 
						best_indiv = Best_individu(population);
						_listStop.set(i,_stopCondition.get(i).stop_condition(best_indiv,50));
					break; 
				}
			}
			
			for(int i = 0; i < _listStop.size(); i++)
			{
				if(_listStop.get(i) == true)
					stop_final = true;
			}
		}while(stop_final == false);
		
		Individu indiv = population.GetIndiv(0);
		Bestgenome = indiv.GetGenome();
		String genome = "Global best genome = ";
		
		for(int i = 0; i < Bestgenome.length; i++)
		{
			if(i > 0)
				genome += "; ";
			
			genome += Bestgenome[i] + " ";
		}		
		System.out.println(genome);
	}

	/**
	 * Fonction qui permet de r�cup�rer le meilleur individu de la population
	 * @return le meilleur individu
	 */
	public Individu Best_individu(Population pop)
	{
		int index = 0;
		Individu indiv1 = new Individu();
		Individu best_individu = new Individu();
		for(int i = 0; i < pop.GetPopulation().size(); i++)
		{
			indiv1 = pop.GetIndiv(i);
			best_individu = pop.GetIndiv(index);
			if(indiv1.GetPoids() < best_individu.GetPoids())
				index = i;
		}
		return best_individu;
	}
}
