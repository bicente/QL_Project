/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Vincent GRUEL
 */
public class ThreadEvaluate extends Thread
{
	/**
	 * Objet de type Individu
	 */
	private Individu indivToEval;
	/**
	 * Objet de type Genome pour �valuer le poids
	 */
	private Genome _genome;
	/**
	 * D�lai pour permettre � un autre thread de s'�x�cuter
	 */
	private static final int DELAI=200;
	/**
	 * Poids � affecter � l'individu �valu�
	 */
	private int _poids;
	/**
	 * La fonction mono_objectif � r�soudre pour calculer le poids de l'individu
	 */
	//Ajouter un objet qui correspond au type de la fonction � optimiser
	
	/**
	 * Constructeur du Thread d'�valuation
	 * @return Pas de valeur de retour
	 */
	public ThreadEvaluate(Individu indiv)//Ajouter la fonction � optimiser dans le constructeur
	{
		indivToEval=indiv;
		//Lier la fonction r�cup�r�e en param�tre � celle de la classe
	}
	
	/**
	 * Fonction Run du Thread avec une pause permettant aux autres Threads de s'�x�cuter en parall�le
	 * @return Pas de valeur de retour
	 */
	public void run()
	{
		try
		{
			_genome=indivToEval.GetGenome();//Fonction pour r�cup�rer le g�nome X
			/*Calcul du poids (j'ai besoin de la fonction � optimiser pour le faire Anthony ;) )
			 	* � coder 	
			 */
			indivToEval.SetPoids(_poids);
			sleep(DELAI);
		}
		catch(InterruptedException e)
		{
			
		}
	}
}
