/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Thibault POULHALEC
 */
public class Individu 
{
	private Genome _genome;
	private int _poids;
	
	Individu()
	{
		
	}
	
	/**
	 * Fonction qui retourne un g�nome pour calcul du poids dans la fonction d'�valuation
	 * @return Un objet de type G�nome aussi consid�r� comme �tant une solution possible du probl�me (coordonn�es X et Y)
	 */
	public Genome GetGenome()
	{
		return _genome;
	}
	
	/**
	 * Fonction qui permet d'affecter le poids de l'individu
	 * @return Pas de valeur de retour
	 */
	public void SetPoids(int poids)
	{
		_poids=poids;
	}
	
	/**
	 * R�cup�ration du poids d'un individu
	 * @return Le poids de l'individu
	 */
	public int GetPoids()
	{
		return _poids;
	}
}
