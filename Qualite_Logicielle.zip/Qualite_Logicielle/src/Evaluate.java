import java.awt.List;
import java.util.ArrayList;

/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Vincent GRUEL
 */
public class Evaluate
{
	int i=0;
	private Population _population;
	//Ajouter la fonction math�matique qu'on doit optimiser
	
	Evaluate(Population population)//Ajouter un objet de type fonction mono-objectif dans le constructeur
	{
		_population=population;
		//Lier la fonction r�cup�rer � celle de la classe
	}
	
	/**
	 * Cr�ation de 4 Threads pour �valuer le poids de 4 individus de la population simultan�ment
	 * @return Pas de valeur de retour
	 */
	public void EvaluateAllIndiv()
	{
		for(i=0; i<_population.GetSizePop(); i=i+4)
		{
			ThreadEvaluate t1, t2, t3, t4;
			t1=new ThreadEvaluate(_population.GetIndiv(i));
			t2=new ThreadEvaluate(_population.GetIndiv(i+1));
			t3=new ThreadEvaluate(_population.GetIndiv(i+2));
			t4=new ThreadEvaluate(_population.GetIndiv(i+3));
			
			t1.start();
			t2.start();
			t3.start();
			t4.start();			
		}
	}
	
	
}
