/**
 * Classe qui permet de croiser deux individus
 * @author Adrien Gagnon
 */
public class CrossOver
{
	public CrossOver() {	}

	/**
	 * Fonction qui permet de croiser deux individus
	 * @return un Individu crois�
	 */
	public static Individu crossOver(Individu parent1, Individu parent2)
	{
		// On affecte le g�nome du parent 1 � l'enfant meme si
		// in fine il n'en gardera que la premi�re moiti�
		Individu child = parent1;

		// Si la taille du g�nome des individus est pair et plus grand que 1
		if((parent1.GetGenome().length)%2 == 0)
		{			
			// On ajoute au g�nome de l'enfant, la deuxi�me moiti� du g�nome du parent 2
			for (int i = (parent1.GetGenome().length)/2; i < parent1.GetGenome().length; i++)
				child.SetGenome(i, parent2.GetGenomeIdx(i));
		}
		// Si la taille du g�nome des individus est impair
		else
		{		
			// On ajoute au g�nome de l'enfant, la deuxi�me moiti� du g�nome du parent 2
			for (int i = ((parent1.GetGenome().length)/2)+1; i < parent1.GetGenome().length; i++)
				child.SetGenome(i, parent2.GetGenomeIdx(i));
		}
		return child;
	}
}