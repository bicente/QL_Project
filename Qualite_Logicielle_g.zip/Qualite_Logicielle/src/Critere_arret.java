
public class Critere_arret
{
	Population _pop;
	Individu _ind;
	int _nb_Xiteration = 0;
	int _nb_pop_iteration = 0;
	int _nb_best_iteration =0;

	/**
	 * Constructeur du crit�re d'arr�t
	 * @param pop
	 * @param ind
	 */
	Critere_arret(Population pop, Individu ind)
	{
		_ind = ind;
		_pop = pop;		
	}
	
	/**
	 * Arr�t apr�s un temps donn�
	 * @param time
	 * @param temps_choisit
	 * @return
	 */
	public boolean stop_time(long time, int temps_choisit)
	{
		long lo = System.nanoTime();
		time += 10000000;
		
		if(lo > time)
			return true;
		else
			return false;
	}
	
	/**
	 * Arr�t apr�s un nombre donn� d'it�rations
	 * @param nb_iteration
	 * @return
	 */
	public boolean stop_Xiteration(int nb_iteration)
	{
		if(_nb_Xiteration >= nb_iteration)
			return true;
		else
		{
			_nb_Xiteration += 1;
			System.out.println("nb_Xiteration= " + _nb_Xiteration);
			return false;
		}
	}
	
	/**
	 * Arr�t si la population n'�volue plus
	 * @param pop
	 * @param nb_iteration
	 * @return
	 */
	public boolean stop_population_evolution(Population pop, int nb_iteration)
	{
		boolean flag = false;
		for(int i =0;i < pop.GetPopulation().size(); i++ )
		{
			if(pop.GetPopulation().get(i) != _pop.GetPopulation().get(i))
			{
				_nb_pop_iteration = 0;
				flag = true;
				break;
			}
		}
		if (flag == false)
		{
			_nb_pop_iteration+=1;
			System.out.println("nb_pop_iteration= " + _nb_pop_iteration);
		}
		else
			_pop.SetPopulation(pop.GetPopulation());
		
		if(_nb_pop_iteration >= nb_iteration)
			return true;
		else
			return false;
	}
	
	/**
	 * Arr�t si le meilleur individu a �t� trouv�
	 * @param ind
	 * @param nb_iteration
	 * @return
	 */
	public boolean stop_individu_meilleur(Individu ind, int nb_iteration)
	{
		if(ind == _ind)
		{
			_nb_best_iteration += 1;
			System.out.println("nb_best_iteration= " + _nb_best_iteration);
		}
		else
			_ind = ind;
		
		if(_nb_best_iteration >= nb_iteration)
			return true;
		else
			return false;
	}
}
