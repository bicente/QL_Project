public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Algorithme al = new Algorithme(2,"F(x,y)=2*x+sin(y)", 0, 10);
	}
}
