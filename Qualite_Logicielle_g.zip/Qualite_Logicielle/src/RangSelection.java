import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RangSelection extends Select
{

	public RangSelection()
	{

	}

	@Override
	public  List<Individu> Selection(Population pop , int nb_parent_selected)
	{
		ArrayList<Individu> _pop=new ArrayList<Individu>();
		_pop = pop.GetPopulation();

		Collections.sort(_pop, new Sortbyroll()); 

		pop.SetPopulation(_pop);

		List<Individu> liste_parents=new ArrayList<Individu>();

		for(int j = _pop.size() - 1; j > _pop.size() - nb_parent_selected; j--)
			liste_parents.add(_pop.get(j));
		
		return liste_parents;
	}

}
