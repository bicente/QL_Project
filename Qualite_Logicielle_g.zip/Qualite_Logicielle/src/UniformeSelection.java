import java.util.ArrayList;
import java.util.List;

public class UniformeSelection extends  Select{

	@Override
	public  List<Individu> Selection(Population pop,  int nb_parent_selected )
	{
		// Population tournament = new Population(tournamentSize, false);
		// For each place in the tournament get a random individual
		ArrayList<Individu> _pop = new ArrayList<Individu>();
		for(int i=0; i<pop.GetSizePop();i++)
			_pop.add(pop.GetPopulation().get(i));

		List<Individu> liste_parents = new ArrayList<Individu>();

		for(int j=0; j < nb_parent_selected;j++)
		{
			int randomId = (int) (Math.random() * _pop.size());

			liste_parents.add(_pop.get(randomId));
			_pop.remove(randomId);
		}
		
		return liste_parents;
	}

}
