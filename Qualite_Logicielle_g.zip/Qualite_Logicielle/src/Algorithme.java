import java.util.ArrayList;
import java.util.List;

import src.org.mariuszgromada.math.mxparser.*;
/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Anthony BONNEFOIS
 */
public class Algorithme 
{
	private Population _population;
	private Evaluate _evaluate;
	private String _function="";
	private double _mutation_rate = 0.03;

	/**
	 * Algorithme de traitement qui retourne la solution optimale a notre fonction
	 * @param size
	 * @param function
	 * @param xmin
	 * @param xmax
	 */
	Algorithme(int size, String function, int xmin, int xmax)//Il faut mettre la taille de la population, la fonction, le m�thode de s�l�ction, les crit�res d'arr�t
	{
		_function=function;

		// Cr�ation de la population
		_population=new Population(30, 0, 10);

		// Cr�ation du critere d'arret
		Critere_arret crt_arret = new Critere_arret(_population,Best_individu(_population));
		
		// Variable pour la gestion du crit�re d'arr�t
		long time = System.nanoTime();
		boolean stop = false;

		// -- Selection du type d'arret souhait� -- \\
		String choixSelection ="Aleatoire";
		Select rang;

		switch (choixSelection)
		{
			case "Rang":  rang = new RangSelection();
			break;        
			case "Tournois": rang = new TourneeSelection();
			break;
			case "Aleatoire": rang = new UniformeSelection();
			break;
			default: rang = new RangSelection();
			break;
		}

		// Cr�ation de la liste d'individus qui seront crois�s et mut�s
		List<Individu> list_parent_selected = new ArrayList<Individu>();

		do
		{
			// -- �valuation de la population -- \\
			_evaluate=new Evaluate(_population, _function);
			_population.SetPopulation(_evaluate.EvaluateAllIndiv());

			list_parent_selected= rang.Selection(_population,5);
			// Cr�ation d'une liste d'individu qui vont �tre crois�s
			List<Individu> list_child_crossed = new ArrayList<Individu>();

			// -- Croisement -- \\

			// Croise l'�l�ment de la liste i avec celui d'apr�s et ajoute l'individu cr�� � la liste d'individus crois�s
			for(int i = 0; i < list_parent_selected.size(); i++)
			{
				if(i<list_parent_selected.size()-1)
				{
					list_child_crossed.add(CrossOver.crossOver(list_parent_selected.get(i), list_parent_selected.get(i + 1)));
				}
			}
				
			// -- Mutation -- \\
			
			// R�affecte l'individu i potentiellement mut� � la population, � la place de l'individu i non mut�
			for(int i=0; i < list_parent_selected.size(); i++)
				_population.SetIndiv(i, Mutate.mutate(_population.GetIndiv(i), _mutation_rate));

			// -- Choix du critere arret -- \\
			Individu best_indiv = Best_individu(_population);
			String _choix_crt_arret ="meilleur individu";

			switch (_choix_crt_arret) 
			{
				case "Temps": stop= crt_arret.stop_time(time,10);
				break;        
				case "X iteration": stop= crt_arret.stop_Xiteration(100);
				break;
				case "population similaire": stop= crt_arret.stop_population_evolution(_population, 5);		
				break;
				case "meilleur individu": stop= crt_arret.stop_individu_meilleur(best_indiv, 5);
				break;
				default: rang= new RangSelection();
				break; 
			}
		}while(stop == false);
	}

	/**
	 * 
	 * Fonction qui permet de r�cup�rer le meilleur individu de la population
	 * @return le meilleur individu
	 */
	public Individu Best_individu(Population pop)
	{
		int index = 0;

		for(int i = 0; i < pop.GetPopulation().size(); i++)
		{
			if(pop.GetPopulation().get(i).GetPoids() > pop.GetPopulation().get(index).GetPoids())
				index = i;
		}
		return pop.GetPopulation().get(index);
	}
}
