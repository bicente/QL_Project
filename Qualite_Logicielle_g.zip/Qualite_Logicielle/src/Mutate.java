/**
* Classe qui permet de muter un individu
* @author Thibault Poulhalec
*/
public class Mutate
{
	private static final double mutationRate = 0.03;
	private static double _mutationrate = 0;
	
	/**
	 * Constructeur d'un objet Mutate
	 */
	public Mutate() {	}
	
	/**
	* Fonction qui permet de muter un individu
	* @return un Individu mut� ou non
	*/
	public static Individu mutate(Individu indiv, double rate)
	{
		//On v�rifie que le taux de mutation est compris entre 0 et 1
		if(rate >= 0 && rate <= 1)
			_mutationrate = rate;
		else
			_mutationrate = mutationRate;
			
		if (Math.random() <= _mutationrate)
		{
			// Rentrer la fonction mutation de l'utilisateur
		}
		return indiv;
	}
}