import src.org.mariuszgromada.math.mxparser.*;
/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Anthony BONNEFOIS
 */
public class Algorithme 
{
	Population _population;
	Evaluate _evaluation;
	String _function="";
	
	Algorithme(int size, String function)//Il faut mettre la taille de la population, la fonction, le m�thode de s�l�ction, les crit�res d'arr�t
	{
		_function=function;
		
		//Cr�ation de la population
		_population=new Population(size);
		
		//�valuation de la population
		_evaluation=new Evaluate(_population, _function);
		_population.SetPopulation(_evaluation.EvaluateAllIndiv());
		
		//Croisement
		
		//Mutation
	}
}
