import java.util.*; 

/**
 * Fonction trouv�e sur internet que nous avons adapter � notre projet
 * Elle permet de comparer deux individus
 */
public class Sortbyroll  implements Comparator<Individu>
{
	/**
	 * Fonction qui permet de comparer 2 Individus
	 * @return un entier en fonction de quel individu a un poids plus �lev� que l'autre
	 */
    public int compare(Individu a, Individu b) 
    { 
    	if(a.GetPoids() < b.GetPoids())
    		return -1;
    	if(a.GetPoids() > b.GetPoids())
    		return 1;
    	
    	return 0;	
    }
}

