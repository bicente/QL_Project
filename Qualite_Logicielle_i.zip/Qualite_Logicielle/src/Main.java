public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Algorithm al = new Algorithm(2,"F(x,y)=x*2+y", 0, 10);
	}
}
