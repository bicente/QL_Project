/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Thibault POULHALEC
 */
public class Individu 
{
	private Genome _genome;
	private double _poids;
	/**
	 * Creation individu
	 * Appel de la fonction de cr�ation des individus rentr�e par l'utilisateur
	 */
	Individu()
	{
		_genome= new Genome(2, 0, 10000);
	}

	/**
	 * Fonction qui retourne tous les g�nomes pour calcul du poids dans la fonction d'�valuation
	 * @return Un objet de type G�nome aussi consid�r� comme �tant une solution possible du probl�me (coordonn�es X et Y)
	 */
	public double[] GetGenome()
	{
		double ParamGenome[]= new double[_genome.GetSize()];
		for(int i = 0; i < _genome.GetSize(); i++)
			ParamGenome[i]=_genome.GetGenome(i);
		
		return ParamGenome;
	}

	/**
	 * Fonction qui retourne un g�nome � l'index choisit
	 * @param idx
	 * @return un g�nome sous la forme d'un double
	 */
	public double GetGenomeIdx(int idx)
	{
		double ParamGenome= 0;
		ParamGenome=_genome.GetGenome(idx);
		return ParamGenome;
	}

	/**
	 * Fonction pour modifier un g�nome en fonction de l'index choisit par l'utilisateur
	 * @param idx
	 * @param value
	 */
	public void SetGenome(int idx, double value)
	{
		_genome.SetGenome(idx,value);
	}

	/**
	 * Fonction qui permet d'affecter le poids de l'individu
	 * @return Pas de valeur de retour
	 */
	public void SetPoids(double poids)
	{
		_poids=poids;
	}

	/**
	 * R�cup�ration du poids d'un individu
	 * @return Le poids de l'individu
	 */
	public double GetPoids()
	{
		return _poids;
	}
}
