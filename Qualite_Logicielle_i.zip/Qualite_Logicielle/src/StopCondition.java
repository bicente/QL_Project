/**
 * Classe qui g�re le crit�re d'arr�t du programme
 * @author Anthony Bonnefois
 */
public class StopCondition
{
	Population _pop;
	Individu _ind;
	int _nb_Xiteration = 0;
	int _nb_pop_iteration = 0;
	int _nb_best_iteration =0;

	/**
	 * Constructeur du crit�re d'arr�t
	 */
	StopCondition(Population pop, Individu ind)
	{
		_ind = ind;
		_pop = pop;		
	}
	
	/**
	 * Arr�t apr�s un temps donn�
	 * @return
	 */
	public boolean stop_time(long time, int temps_choisit)
	{
		
		long lo = System.nanoTime();
		
		long timer =time +time/10000;
		if(lo > timer)
			return true;
		else
			return false;
	}
	
	/**
	 * Arr�t apr�s un nombre donn� d'it�rations
	 * @return
	 */
	public boolean stop_Xiteration(int nb_iteration)
	{
		if(_nb_Xiteration >= nb_iteration)
			return true;
		
		else
		{
			_nb_Xiteration += 1;
			System.out.println("nb_Xiteration= " + _nb_Xiteration);
			return false;
		}
	}
	
	/**
	 * Arr�t si la population n'�volue plus
	 * @return
	 */
	public boolean stop_population_evolution(Population pop, int nb_iteration)
	{
		boolean flag = false;
		for(int i = 0; i < pop.GetPopulation().size(); i++ )
		{
			if(pop.GetPopulation().get(i) != _pop.GetPopulation().get(i))
			{
				_nb_pop_iteration = 0;
				flag = true;
				break;
			}
		}
		
		if (flag == false)
			_nb_pop_iteration+=1;
		else
			_pop.SetPopulation(pop.GetPopulation());
		
		if(_nb_pop_iteration >= nb_iteration)
			return true;
		else
			return false;
	}
	
	/**
	 * Arr�t si le meilleur individu a �t� trouv�
	 * @return
	 */
	public boolean stop_individu_meilleur(Individu ind, int nb_iteration)
	{
		if(ind == _ind)
			_nb_best_iteration += 1;
		else
		{
			_ind = ind;
			_nb_best_iteration=0;
		}
		
		if(_nb_best_iteration >= nb_iteration)
			return true;
		else
			return false;
	}
}
