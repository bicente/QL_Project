import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Anthony BONNEFOIS
 */
public class Algorithm 
{
	//private Population _population;
	private Evaluate _evaluate;
	private String _function="";
	private double _mutation_rate = 0.03;
	private int nb_created_children = 20;
	private double[] Bestgenome;

	/**
	 * Algorithme de traitement qui retourne la solution optimale a notre fonction
	 */
	Algorithm(int size, String function, int xmin, int xmax) // Il faut mettre la taille de la population, la fonction, le m�thode de s�l�ction, les crit�res d'arr�t
	{
		_function = function;

		// Cr�ation de la population
		Population population=new Population(100, 0, 10);

		// Cr�ation du critere d'arret
		StopCondition stop_condition = new StopCondition(population,Best_individu(population));
		
		// Variables pour la gestion du crit�re d'arr�t
		long time = System.nanoTime();
		boolean stop = false;

		// -- Selection du type d'arret souhait� -- \\
		String choixSelection ="Rank";
		Select rank;

		switch (choixSelection)
		{
			case "Rank":  rank = new RankSelection();
			break;        
			case "Tournament": rank = new TournamentSelection();
			break;
			case "Random": rank = new UniformeSelection();
			break;
			default: rank = new RankSelection();
			break;
		}

		// Cr�ation de la liste d'individus qui seront crois�s et mut�s
		List<Individu> list_selected_parent = new ArrayList<Individu>();
		
		// -- �valuation de la population -- \\
		_evaluate = new Evaluate(population, _function);
		population.SetPopulation(_evaluate.EvaluateAllIndiv());
		
		do
		{
			// Trie les elements de la liste par ordre decroissant en fonction de leur poids
			ArrayList<Individu> _intermediate_pop = new ArrayList<Individu>();
			_intermediate_pop = population.GetPopulation();
			Collections.sort(_intermediate_pop, new Sortbyroll()); 	
			population.SetPopulation(_intermediate_pop);
			
			// Selection des parents pour cr�er les nb enfant
			list_selected_parent= rank.Selection(population, nb_created_children + 1);
			
			// Cr�ation d'une liste d'individu qui contient les enfant
			List<Individu> list_crossed_children = new ArrayList<Individu>();

			// -- Croisement -- \\

			// Croise l'�l�ment de la liste i avec celui d'apr�s et ajoute l'individu cr�� � la liste d'individus crois�s
			for(int i = 0; i < list_selected_parent.size(); i++)
			{
				if(i<list_selected_parent.size()-1)
					list_crossed_children.add(CrossOver.crossOver(list_selected_parent.get(i), list_selected_parent.get(i + 1)));
			}
				
			// -- Mutation -- \\
			
			// R�affecte l'individu i potentiellement mut� � la population, � la place de l'individu i non mut�
			for(int i=0; i < list_crossed_children.size(); i++)
				list_crossed_children.set(i, Mutate.mutate(list_crossed_children.get(i), _mutation_rate));
			
			// Creation de la population d'enfant
			Population list_children = new Population(nb_created_children, 0, 10);

			for(int i=0; i < nb_created_children; i++)
				list_children.SetIndiv(i, list_crossed_children.get(i));
			
			// -- �valuation de la population d'enfant-- \\
			_evaluate=new Evaluate(list_children, _function);
			list_children.SetPopulation(_evaluate.EvaluateAllIndiv());
			
			// Selection de la methode de remplacement des parents par les enfants
			String replacement_methode_choice = "Best individu";

			switch (replacement_methode_choice) 
			{
				case "Best individu": 

					for(int i=0;i<list_children.GetSizePop();i++)
					{
						for(int j=0; j<population.GetSizePop();j++)
						{
							if(list_children.GetPopulation().get(i).GetPoids()>population.GetPopulation().get(j).GetPoids())
							{
								for(int k=population.GetSizePop()-1;k>j;k--)
									population.SetIndiv(k, population.GetPopulation().get(k-1));	
								
								population.SetIndiv(j, list_children.GetPopulation().get(i));
								break;
							}
						}
					}
					
				break;        
				case "Random": 
					int randomId = 1;
					for(int i=0;i<list_children.GetSizePop();i++)
					{		
							do
							{
								randomId = (int) (Math.random() * population.GetSizePop());
							}while(randomId==0);
							
							population.SetIndiv(randomId, list_children.GetPopulation().get(i));
					}
				break;
				default: 
					for(int i=0;i<list_children.GetSizePop();i++)
					{
						for(int j=0; j<population.GetSizePop();j++)
						{
							if(list_children.GetPopulation().get(i).GetPoids()>population.GetPopulation().get(j).GetPoids())
							{
								for(int k = population.GetSizePop()-1; k > j; k--)
									population.SetIndiv(k, population.GetPopulation().get(k-1));	
								
								population.SetIndiv(j, list_children.GetPopulation().get(i));
								break;
							}
						}
					}
				break; 
			}
			
			// -- Choix du critere arret -- \\
			Individu best_indiv = Best_individu(population);
		
			String stop_condition_choice ="X iterations";
			switch (stop_condition_choice) 
			{
				case "Time": stop= stop_condition.stop_time(time, 10000000);
				break;        
				case "X iterations": stop= stop_condition.stop_Xiteration(100);
				break;
				case "Same Population": stop= stop_condition.stop_population_evolution(population, 10);		
				break;
				case "Best individu": stop= stop_condition.stop_individu_meilleur(best_indiv, 20);
				break;
				default: stop= stop_condition.stop_individu_meilleur(best_indiv, 20);
				break; 
			}
			System.out.println("Best per frame = " + population.GetPopulation().get(0).GetPoids());
		}while(stop == false);
		
		Bestgenome = population.GetPopulation().get(0).GetGenome();
		String genome = "Global best genome = ";
		
		for(int i = 0; i < Bestgenome.length; i++)
		{
			if(i > 0)
				genome += "; ";
			
			genome += Bestgenome[i] + " ";
		}		
		System.out.println(genome);
	}

	/**
	 * Fonction qui permet de r�cup�rer le meilleur individu de la population
	 * @return le meilleur individu
	 */
	public Individu Best_individu(Population pop)
	{
		int index = 0;

		for(int i = 0; i < pop.GetPopulation().size(); i++)
		{
			if(pop.GetPopulation().get(i).GetPoids() > pop.GetPopulation().get(index).GetPoids())
				index = i;
		}
		return pop.GetPopulation().get(index);
	}
}
