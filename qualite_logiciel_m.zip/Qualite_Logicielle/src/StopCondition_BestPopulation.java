import java.util.ArrayList;
import java.util.List;

public class StopCondition_BestPopulation implements  IStopCondition {
	
	int _nb_pop_iteration = 0;
	List<Individu> _pop_list_last;
	boolean first = false;
	
	@Override
	public  boolean stop_condition(Population pop, int nb_iteration)
	{

		
		if(first)
		{
			List<Individu> pop_list = new ArrayList<>();
			pop_list = pop.GetPopulation();
			/*boolean flag = false;
			for(int i = 0; i < pop.GetPopulation().size(); i++ )
			{
				
				pop
				if(pop.GetPopulation().get(i) != _pop.GetPopulation().get(i))
				{
					_nb_pop_iteration = 0;
					flag = true;
					break;
				}
			}
			*/
			
			if (pop_list.equals(_pop_list_last))
			{
				System.out.println("a");
				_nb_pop_iteration+=1;
			}
			else
				_nb_pop_iteration=0;
				_pop_list_last = pop.GetPopulation();
			
			if(_nb_pop_iteration >= nb_iteration)
				return true;
			else
				return false;
		}
		else
		{
			_pop_list_last = pop.GetPopulation();
			first = true;
			return false;
		}
	}

}
