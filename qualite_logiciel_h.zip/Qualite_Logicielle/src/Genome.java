import org.mariuszgromada.math.mxparser.*;

import java.util.ArrayList;

public class Genome 
{
	private Function F;
	ArrayList<Double> _tabGenome= new ArrayList<Double>();
	
	/**
	 * Constructeur d'un objet de type G�nome
	 */
	Genome(double size, int xmin, int xmax)
	{
		// L'utilisateur doit rentrer la fonction permettant de cr�er un G�nome
		// Provisioire
		for(int i=0;i<size;i++)
		{
			int nombreAleatoire = xmin + (int)(Math.random() * ((xmax - xmin) + 1));
			_tabGenome.add((double)nombreAleatoire);
		}
	}
	
	/**
	 * Permet de r�cup�rer le g�nome d'un indivu
	 * @return le g�nome dans un double
	 */
	public double GetGenome(int idx)
	{
		return _tabGenome.get(idx);
	}
	
	/**
	 * Permet d'affecter le g�nome souhait� � un indivu
	 */
	public void SetGenome(int idx, double value)
	{
		_tabGenome.set(idx, value);
	}
	
	/**
	 * Permet de r�cup�rer la taille du g�nome d'un indivu
	 * @return la taille du g�nome dans un entier
	 */
	public int GetSize()
	{
		return _tabGenome.size();
	}
}
