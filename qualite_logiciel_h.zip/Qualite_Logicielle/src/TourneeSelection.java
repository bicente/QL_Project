import java.util.ArrayList;
import java.util.List;

public class TourneeSelection extends Select {
	
	/**
	 * Methode qui retourn n individu en les ayent selctionner avec la methode tournois
	 * @parm pop population
	 * @param nb_parent_selected nombre choisit de parent par l'utilisateur
	 * @return List<Individu>
	 */
	@Override
	public  List<Individu> Selection(Population pop,  int nb_parent_selected )
	{
		ArrayList<Individu> _pop=new ArrayList<Individu>();
		_pop = pop.GetPopulation();
		List<Individu> liste_parents=new ArrayList<Individu>();
		for(int i=0;i< nb_parent_selected;i++)
		{
			int randomId = (int) (Math.random() * _pop.size());
			int randomId2 = (int) (Math.random() * _pop.size());
			int randomId3 = (int) (Math.random() * _pop.size());
			
			int max =Math.max(randomId,randomId2);
			int max2 =Math.max(randomId3,randomId2);
			max2 = Math.max(max,max2);
			liste_parents.add(_pop.get(max2));
			
			
		}
		
		return liste_parents;
		
	}

}
