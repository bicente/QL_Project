import java.util.ArrayList;
import java.util.List;

public class UniformeSelection extends  Select{

	/**
	 * Methode qui retourn n individu de maniere al�atoir dans la liste d'individu
	 * @parm pop population
	 * @param nb_parent_selected nombre choisit de parent par l'utilisateur
	 * @return List<Individu>
	 */
	@Override
	public  List<Individu> Selection(Population pop,  int nb_parent_selected )
	{
		// For each place in the tournament get a random individual
		ArrayList<Individu> _pop = new ArrayList<Individu>();
		for(int i=0; i<pop.GetSizePop();i++)
			_pop.add(pop.GetPopulation().get(i));

		List<Individu> liste_parents = new ArrayList<Individu>();

		for(int j=0; j < nb_parent_selected;j++)
		{
			int randomId = (int) (Math.random() * _pop.size());

			liste_parents.add(_pop.get(randomId));
			_pop.remove(randomId);
		}
		
		return liste_parents;
	}

}
