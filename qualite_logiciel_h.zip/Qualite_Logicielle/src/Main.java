public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Algorithme al = new Algorithme(2,"F(x,y)=x*2+y", 0, 10);
	}
}
