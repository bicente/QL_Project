public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Algorithm al = new Algorithm("F(x,y)=x*2+y", 2, 0, 10000,20,100,"Best individu","X iterations");
	}
}
