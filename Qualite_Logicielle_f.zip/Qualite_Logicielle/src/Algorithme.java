import java.util.ArrayList;
import java.util.List;

import src.org.mariuszgromada.math.mxparser.*;
/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Anthony BONNEFOIS
 */
public class Algorithme 
{
	private Population _population;
	private Evaluate _evaluation;
	private String _function="";
	
	Algorithme(int size, String function, int xmin, int xmax)//Il faut mettre la taille de la population, la fonction, le m�thode de s�l�ction, les crit�res d'arr�t
	{
		_function=function;
		
		//Cr�ation de la population
		_population=new Population(30, 0, 10);

		//Cr�ation et Selction du critere d'arret
		Critere_arret crt_arret = new Critere_arret(_population,Best_individu(_population));
		long time = System.nanoTime();
		boolean stop = false;
		
		//Selection 
		String choixSelection ="Aleatoire";
		Select rang;
		
		switch (choixSelection)
		{
	    	case "Rang":  rang = new RangSelection();
	             break;        
	    	case "Tournois": rang = new TourneeSelection();
	    		break;
	    	case "Aleatoire": rang = new UniformeSelection();
				break;
	    	default: rang = new RangSelection();
	    		break;
		}
		
		List<Individu> list_parent_selected = new ArrayList<Individu>();
		
		do
		{
			//�valuation de la population
			_evaluation=new Evaluate(_population, _function);
			_population.SetPopulation(_evaluation.EvaluateAllIndiv());
			list_parent_selected= rang.Selection(_population,5);
			//Croisement
			
			//Mutation
			Individu best_indiv=Best_individu(_population);
			//Choix du critere arret
			String choix_crt_arret ="meilleur individu";
			switch (choix_crt_arret) 
			{
		    	case "Temps": stop= crt_arret.stop_time(time,10);
		             break;        
		    	case "X iteration": stop= crt_arret.stop_Xiteration(100);
		    		break;
		    	case "population similaire": stop= crt_arret.stop_population_evolution(_population, 5);		
					break;
		    	case "meilleur individu": stop= crt_arret.stop_individu_meilleur(best_indiv, 5);
		    		break;
		    	default: rang= new RangSelection();
		    		break; 
			}
		}while(stop==false);
	}
	
	public Individu Best_individu(Population pop)
	{
		int index = 0;
		
		for(int i=0; i<pop.GetPop().size();i++)
		{
			if(pop.GetPop().get(i).GetPoids()>pop.GetPop().get(index).GetPoids())
			{
				index = i;
			}
		}
		return pop.GetPop().get(index);
	}
}
