/**
* Fonction qui permet de muter un individu
* @return un Individu mut� ou non
*/
public class Mutate
{
	private static final double mutationRate=0.03;
	private double _mutationrate = 0;
	public Mutate()
	{
		
	}
	
	/**
	* Fonction qui permet de muter un individu
	* @return un Individu mut� ou non
	*/
	public Individu mutate(Individu indiv, double rate)
	{
		if(rate >= 0 && rate <= 1)
			_mutationrate = rate;
		else
			_mutationrate = mutationRate;
			
		if (Math.random() <= _mutationrate)
		{
			// Rentrer la fonction mutation de l'utilisateur
		}
		return indiv;
	}
}