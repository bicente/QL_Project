
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author A DEFINIR (I faut aussi faire les classes d�pendantes pour le design pattern "Strategy")
 *
 */
public abstract class Select 
{
	
	
	public abstract List<Individu> Selection(Population pop, int nb_parent_selected );

}
