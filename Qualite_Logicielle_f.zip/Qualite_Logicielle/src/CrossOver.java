/**
* Fonction qui permet de croiser deux individus
* @return un Individu crois�
*/
public class CrossOver
{
	public CrossOver()
	{
	}
	
	/**
	* Fonction qui permet de croiser deux individus
	* @return un Individu crois�
	*/
	public static Individu crossOver(Individu parent1, Individu parent2)
	{
		// On affecte le g�nome du parent 1 � l'enfant mais au final l'enfant n'en gardera que la premi�re moiti�
		Individu enfant = parent1;
		
		// Si les individus n'ont qu'un seul g�ne
		if(parent1.GetGenome().length == 1)
		{
			// 
			double result = (parent1.GetGenomeIdx(0) + parent2.GetGenomeIdx(0)) /2; 
			enfant.SetGenome(0, result);
		}
		else
		{
			// Si la taille du g�nome des individus est paire
			if((parent1.GetGenome().length)%2 == 0)
			{			
				// On ajoute au g�nome de l'enfant, la deuxi�me moiti� du g�nome du parent 2
				for (int i = (parent1.GetGenome().length)/2; i < parent1.GetGenome().length; i++)
					enfant.SetGenome(i, parent2.GetGenomeIdx(i));
			}
			// Si la taille du g�nome des individus est impaire
			else
			{		
				// On ajoute au g�nome de l'enfant, la deuxi�me moiti� du g�nome du parent 2
				for (int i = ((parent1.GetGenome().length)/2)+1; i < parent1.GetGenome().length; i++)
					enfant.SetGenome(i, parent2.GetGenomeIdx(i));
			}
		}
		
		return enfant;
	}
}