import java.awt.List;
import java.util.ArrayList;

/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Vincent GRUEL
 */
public class Evaluate
{
	int i=0;
	int toRecul=0;
	private Population _population;
	private String _function;
	//Ajouter la fonction math�matique qu'on doit optimiser
	
	/**
	 * Constructeur d'un objet de type �valuation
	 * @return Pas de valeur de retour
	 */
	Evaluate(Population population, String function)//Ajouter un objet de type fonction mono-objectif dans le constructeur
	{
		_population=population;
		_function=function;
	}
	
	/**
	 * Cr�ation de 4 Threads pour �valuer le poids de 4 individus de la population simultan�ment
	 * @return Pas de valeur de retour
	 */
	public ArrayList<Individu> EvaluateAllIndiv()
	{
		for(i=0; i<_population.GetSizePop(); i=i+4)
		{
			//System.out.println(i);
			int k=i;
			ArrayList<ThreadEvaluate> _listeThread=new ArrayList<ThreadEvaluate>();
			for(int j=0;j<4;j++)
			{
				if(i+j<_population.GetSizePop())
				{
					_listeThread.add(new ThreadEvaluate(_population.GetIndiv(i+j), _function));
				}
			}
			for(ThreadEvaluate t : _listeThread)
			{
				try
				{
					t.start();
					t.join();
				}
				catch(InterruptedException e)
				{
					
				}
			}
			for(ThreadEvaluate t : _listeThread)
			{
				Individu newIndiv =new Individu();
				newIndiv=_population.GetIndiv(k);
				newIndiv.SetPoids(t.GetPoids());
				//System.out.println(t.GetPoids());
				_population.SetIndiv(k, newIndiv);
				//_population.SetIndiv(idx, t.GetPoids());
				k++;
			}
		}
		return _population.GetPop();
	}
}
