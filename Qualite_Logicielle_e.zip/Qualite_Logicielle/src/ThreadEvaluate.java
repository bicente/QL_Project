import java.util.ArrayList;

import src.org.mariuszgromada.math.mxparser.*;
/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Vincent GRUEL
 */
public class ThreadEvaluate extends Thread
{
	/**
	 * Objet de type Individu
	 */
	private Individu indivToEval;
	/**
	 * Objet de type Genome pour �valuer le poids
	 */
	private double[] _genome;
	/**
	 * D�lai pour permettre � un autre thread de s'�x�cuter
	 */
	private static final int DELAI=100;
	/**
	 * Poids � affecter � l'individu �valu�
	 */
	private double _poids;
	/**
	 * Un objet de type fonction qui nous permettra de calculer le poids
	 */
	private Function F;
	
	
	/**
	 * Constructeur du Thread d'�valuation
	 * @return Pas de valeur de retour
	 */
	public ThreadEvaluate(Individu indiv, String function)//Ajouter la fonction � optimiser dans le constructeur
	{
		indivToEval=indiv;
		F=new Function(function);
	}
	
	/**
	 * Fonction Run du Thread avec une pause permettant aux autres Threads de s'�x�cuter en parall�le
	 * @return Pas de valeur de retour
	 */
	public void run()
	{
		try
		{
			String exp="F(";
			_genome=indivToEval.GetGenome();//Fonction pour r�cup�rer le g�nome X
			for(int i=0;i<indivToEval.GetGenome().length;i++)
			{
				if(i>0)
				{
					exp+=",";
				}
				exp+=""+String.valueOf(indivToEval.GetGenome()[i])+"";
			}
			exp+=")";
			//System.out.println(exp);
			Expression e2 = new Expression(exp,F);
			_poids=e2.calculate();
			//System.out.println(_poids);
			sleep(DELAI);
			
			
			/*_genome=indivToEval.GetGenome();//Fonction pour r�cup�rer le g�nome X
			FirstParam="x = "+String.valueOf(_genome[0])+"";
			SecondParam="y = "+String.valueOf(_genome[1])+"";
			Argument X=new Argument(FirstParam);
			Argument Y=new Argument(SecondParam);
			//Calcul du poids
			Expression e2 = new Expression("F(x,y)",F,X,Y);
			_poids=e2.calculate();
			sleep(DELAI);*/
		}
		catch(InterruptedException e)
		{
			
		}
	}
	
	public double GetPoids()
	{
		return _poids;
	}
}
