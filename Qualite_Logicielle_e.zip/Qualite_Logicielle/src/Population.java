import java.util.ArrayList;

/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Adrien GAGNON
 */
public class Population 
{
	/**
	 * Liste de tous les individus qui composent la population
	 */
	ArrayList<Individu> _population=new ArrayList<Individu>();
	/**
	 * Objet utilis� pour cr�er un individu
	 */
	Individu indiv;
	
	/**
	 * Cr�ation de la population en fonction de la taille sp�cifi�e par l'utilisateur
	 * @return Pas de valeur de retour
	 */
	Population(int size, int xmin, int xmax)
	{
		for(int i=0; i<size;i++)
		{
			//Cr�ation des individus
			indiv=new Individu();
			_population.add(indiv);
		}
	}
	
	/**
	 * Fonction pour r�cup�rer un individu � l'indice "idx" dans la population
	 * @return Un objet de type Individu
	 */
	public Individu GetIndiv(int idx)
	{
		Individu newIndiv=_population.get(idx);
		return newIndiv;
	}
	
	public void SetIndiv(int idx, Individu indiv)
	{
		_population.set(idx, indiv);
	}
	
	public void SetPopulation(ArrayList<Individu> pop)
	{
		_population=pop;
	}
	/**
	 * Fonction qui retourne un g�nome pour calcul du poids dans la fonction d'�valuation
	 * @return Un objet de type G�nome aussi consid�r� comme �tant une solution possible du probl�me (coordonn�es X et Y)
	 */
	public int GetSizePop()
	{
		return _population.size();
	}
	
	public ArrayList<Individu> GetPop()
	{
		return _population;
	}
}
