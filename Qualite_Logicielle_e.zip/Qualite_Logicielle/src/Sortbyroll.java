

import java.util.*; 
import java.lang.*; 
import java.io.*; 

public class Sortbyroll  implements Comparator<Individu> {
	
	// Used for sorting in ascending order of 
    // roll number 
    public int compare(Individu a, Individu b) 
    { 
    	
    	if(a.GetPoids() < b.GetPoids())
    	{
    		return -1;
    	}
    	if(a.GetPoids() > b.GetPoids())
    	{
    		return 1;
    	}
    	return 0;
    		
    } 

}

