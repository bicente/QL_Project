import src.org.mariuszgromada.math.mxparser.*;

import java.util.ArrayList;

public class Genome 
{
	private Function F;
	ArrayList<Double> _tabGenome= new ArrayList<Double>();
	
	/**
	 * Constructeur d'un objet de type G�nome
	 */
	Genome(double size, int xmin, int xmax)
	{
		// Provisioire
		for(int i=0;i<size;i++)
		{
			int nombreAleatoire = xmin + (int)(Math.random() * ((xmax - xmin) + 1));
			_tabGenome.add((double)nombreAleatoire);
		}
	}
	
	public double GetGenome(int idx)
	{
		return _tabGenome.get(idx);
	}
	
	public void SetGenome(int idx, double value)
	{
		_tabGenome.set(idx, value);
	}
	
	public int GetSize()
	{
		return _tabGenome.size();
	}
}
