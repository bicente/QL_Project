
public class Critere_arret {
	
	Population _pop;
	int nb_Xiteration=0;
	int nb_pop_iteration = 0;
	int nb_best_iteration =0;
	Individu _ind;

	Critere_arret(Population pop, Individu ind)
	{
		_ind = ind;
		_pop = pop;
		
		
	}
	public boolean stop_time(long time, int temps_choisit)
	{
		long lo= System.nanoTime();
		time +=10000000;
		if(lo>time)
		{
			//System.out.println("Gan lo = "+lo+"time= "+time+" lo + time= "+lo+time);
			return true;
		}
		else
		{
			//System.out.println("Per lo = "+lo+"time= "+time+" lo + time= "+lo+time);
			return false;
		}
		
	}
	public boolean stop_Xiteration(int nb_iteration)
	{
		if(nb_Xiteration>=nb_iteration)
		{
			return true;
		}
		else
		{
			nb_Xiteration+=1;
			System.out.println("nb_Xiteration= "+nb_Xiteration);
			return false;
		}
		
	}
	public boolean stop_population_evolution(Population pop, int nb_iteration)
	{
		boolean flag = false;
		for(int i =0;i< pop.GetPop().size();i++ )
		{
			if(pop.GetPop().get(i)!=_pop.GetPop().get(i))
			{
				nb_pop_iteration=0;
				flag=true;
				break;
			
			}
		}
		if (flag==false)
		{
			nb_pop_iteration+=1;
			System.out.println("nb_pop_iteration= "+nb_pop_iteration);
		}
		else
		{
			_pop.SetPopulation(pop.GetPop());
		}
		
		if(nb_pop_iteration>=nb_iteration)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	
	public boolean stop_individu_meilleur(Individu ind, int nb_iteration)
	{
		if(ind == _ind)
		{
			nb_best_iteration += 1;
			System.out.println("nb_best_iteration= "+nb_best_iteration);
		}
		else
		{
			_ind = ind;
		}
		if(nb_best_iteration>=nb_iteration)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
