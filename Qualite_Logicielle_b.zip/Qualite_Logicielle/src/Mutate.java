/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Anthony BONNEFOIS
 */
public class Mutate {

}
