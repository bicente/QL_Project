
public class Genome 
{
	
	/**
	 * Constructeur d'un objet de type G�nome, au choix un vecteur de 2 entiers ou un un vecteur de 2*5bits
	 */
	Genome()
	{
		
	}
}
