/**
 * 
 * @author A DEFINIR (I faut aussi faire les classes d�pendantes pour le design pattern "Strategy")
 *
 */
public class Select 
{

}
