import java.awt.List;
import java.util.ArrayList;

/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Vincent GRUEL
 */
public class Evaluate
{
	int i=0;
	int toRecul=0;
	private Population _population;
	private String _function;
	//Ajouter la fonction math�matique qu'on doit optimiser
	
	Evaluate(Population population, String function)//Ajouter un objet de type fonction mono-objectif dans le constructeur
	{
		_population=population;
		_function=function;
		
	}
	
	/**
	 * Cr�ation de 4 Threads pour �valuer le poids de 4 individus de la population simultan�ment
	 * @return Pas de valeur de retour
	 */
	public void EvaluateAllIndiv()
	{
		for(i=0; i<_population.GetSizePop(); i=i+4)
		{
			ThreadEvaluate t1, t2, t3, t4;
			t1=new ThreadEvaluate(_population.GetIndiv(i), _function);
			t2=new ThreadEvaluate(_population.GetIndiv(i+1), _function);
			t3=new ThreadEvaluate(_population.GetIndiv(i+2), _function);
			t4=new ThreadEvaluate(_population.GetIndiv(i+3), _function);
			
			t1.start();
			t2.start();
			t3.start();
			t4.start();
			//On teste la valeur de i pour bien �valuer tous les individus quitte � �valuer au maximum 3 individus 2 fois
			if(i+4>_population.GetSizePop())
			{
				int diff=0;
				diff=_population.GetSizePop()-i;
				toRecul=4-diff;
				i=i-toRecul;
			}
		}
	}
	
	
}
