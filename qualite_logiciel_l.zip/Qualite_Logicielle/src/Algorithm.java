import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * �valuation de la population en fonction des param�tres de chaque individu et de la fonction � optimiser
 * @author Anthony BONNEFOIS
 */
public class Algorithm 
{
	//private Population _population;
	private Evaluate _evaluate;
	private Evaluate _evaluate2;
	private String _function="";
	private double _mutation_rate = 0.03;
	private int _nb_created_children = 20;
	private int _sizepopulation =100;
	private double[] Bestgenome;
	private String _replacement_methode_choice ="Best individu";
	private String _stop_condition_choice= "X iterations";
	private String _choixSelection ="Rank";

	/**
	 * Algorithme de traitement qui retourne la solution optimale a notre fonction
	 */
	Algorithm(String function, int SizeGenome, int xmin, int xmax, int nb_created_children, int sizepopulation, String replacement_methode_choice,String stop_condition_choice, String choixSelection ) // Il faut mettre la taille de la population, la fonction, le m�thode de s�l�ction, les crit�res d'arr�t
	{
		_choixSelection =choixSelection;
		_stop_condition_choice = stop_condition_choice;
		_replacement_methode_choice =replacement_methode_choice;
		_sizepopulation = sizepopulation;
		_nb_created_children = nb_created_children;
		_function = function;
		
		Individu  best_indiv;
		int test = 0;
		// Cr�ation de la population
		Population population=new Population(_sizepopulation, SizeGenome, xmin, xmax);

		
		// Variables pour la gestion du crit�re d'arr�t
		long time = System.nanoTime();
		boolean stop = false;

		// -- Selection du type d'arret souhait� -- \\
		
		Select rank;

		switch (_choixSelection)
		{
			case "Rank":  rank = new RankSelection();
			break;        
			case "Tournament": rank = new TournamentSelection();
			break;
			case "Random": rank = new UniformeSelection();
			break;
			default: rank = new RankSelection();
			break;
		}

		// Cr�ation de la liste d'individus qui seront crois�s et mut�s
		List<Individu> list_selected_parent = new ArrayList<Individu>();
		
		// -- �valuation de la population -- \\
		_evaluate = new Evaluate(population, _function);
		population.SetPopulation(_evaluate.EvaluateAllIndiv());
		
		//Choix du critere d'arret
		StopConditionFactory stop_Factory = new StopConditionFactory();
		 IStopCondition stop_Condition = stop_Factory.getStopCondition(_stop_condition_choice);
		
		do
		{
			// Trie les elements de la liste par ordre decroissant en fonction de leur poids
			ArrayList<Individu> _intermediate_pop = new ArrayList<Individu>();
			_intermediate_pop = population.GetPopulation();
			Collections.sort(_intermediate_pop, new Sortbyroll()); 	
			population.SetPopulation(_intermediate_pop);
			
			 for(int i=0;i<population.GetSizePop();i++)
			 {
				 System.out.println("pop= " + population.GetIndiv(i));
				 System.out.println("pop= " + population.GetIndiv(i).GetPoids());
			 }
			
			// Selection des parents pour cr�er les nb enfant
			list_selected_parent= rank.Selection(population, _nb_created_children + 1);
			
			// Cr�ation d'une liste d'individu qui contient les enfant
			List<Individu> list_crossed_children = new ArrayList<Individu>();

			// -- Croisement -- \\

			Random r = new Random();
			
			// Croise l'�l�ment de la liste i avec celui d'apr�s et ajoute l'individu cr�� � la liste d'individus crois�s
			for(int i = 0; i < list_selected_parent.size()-1; i++)
			{
				//if(i<list_selected_parent.size()-1)
					list_crossed_children.add(CrossOver.crossOver(list_selected_parent.get(r.nextInt(list_selected_parent.size())), list_selected_parent.get(r.nextInt(list_selected_parent.size()))));
			}
				
			// -- Mutation -- \\
			
			// R�affecte l'individu i potentiellement mut� � la population, � la place de l'individu i non mut�
			for(int i=0; i < list_crossed_children.size(); i++)
				list_crossed_children.set(i, Mutate.mutate(list_crossed_children.get(i), _mutation_rate));

			
			// Creation de la population d'enfant
			Population list_children = new Population(nb_created_children, SizeGenome, xmin, xmax);

			for(int i=0; i < nb_created_children; i++)
				list_children.SetIndiv(i, list_crossed_children.get(i));
			
			// -- �valuation de la population d'enfant-- \\
			_evaluate2=new Evaluate(list_children, _function);
			list_children.SetPopulation(_evaluate2.EvaluateAllIndiv());
			
			
			 for(int i=0;i<list_children.GetSizePop();i++)
			 {
				 System.out.println("children ind= " + list_children.GetIndiv(i));
				 System.out.println("children poid = " + list_children.GetIndiv(i).GetPoids());
			 }
			// Selection de la methode de remplacement des parents par les enfants
			switch (_replacement_methode_choice) 
			{
				case "Best individu": 

					for(int i=0;i<list_children.GetSizePop();i++)
					{
						for(int j=0; j<population.GetSizePop();j++)
						{
							if(list_children.GetPopulation().get(i).GetPoids()<population.GetPopulation().get(j).GetPoids())
							{
								for(int k=population.GetSizePop()-1;k>j;k--)
								{
									population.SetIndiv(k, population.GetPopulation().get(k-1));	
								}
								
								
								population.SetIndiv(j, list_children.GetPopulation().get(i));
								break;
							}
						}
					}
					
				break;        
				case "Random": 
					int randomId = 1;
					for(int i=0;i<list_children.GetSizePop();i++)
					{		
							do
							{
								randomId = (int) (Math.random() * population.GetSizePop());
							}while(randomId==0);
							
							population.SetIndiv(randomId, list_children.GetPopulation().get(i));
					}
				break;
				default: 
					for(int i=0;i<list_children.GetSizePop();i++)
					{
						for(int j=0; j<population.GetSizePop();j++)
						{
							if(list_children.GetPopulation().get(i).GetPoids()>population.GetPopulation().get(j).GetPoids())
							{
								for(int k = population.GetSizePop()-1; k > j; k--)
									population.SetIndiv(k, population.GetPopulation().get(k-1));	
								
								population.SetIndiv(j, list_children.GetPopulation().get(i));
								break;
							}
						}
					}
				break; 
			}
			 for(int i=0;i<population.GetSizePop();i++)
			 {
				 System.out.println("population individu2 = " + population.GetIndiv(i));
				 System.out.println("population poid2 = " + population.GetIndiv(i).GetPoids());
			 }
			 System.out.println("test="+test);
			// -- Choix du critere arret -- \\
			 best_indiv = Best_individu(population);
			 System.out.println("\n");
			stop =stop_Condition.stop_condition(2);
			test+=1;
			/*
			switch (_stop_condition_choice) 
			{
				case "Time": stop= stop_condition.stop_time(time, 10000000);
				break;        
				case "X iterations": stop= stop_condition.stop_Xiteration(100);
				break;
				case "Same Population": stop= stop_condition.stop_population_evolution(population, 10);		
				break;
				case "Best individu": stop= stop_condition.stop_individu_meilleur(best_indiv, 20);
				break;
				default: stop= stop_condition.stop_individu_meilleur(best_indiv, 20);
				break; 
			}*/
		}while(stop == false);
		
		Bestgenome = population.GetPopulation().get(0).GetGenome();
		String genome = "Global best genome = ";
		
		for(int i = 0; i < Bestgenome.length; i++)
		{
			if(i > 0)
				genome += "; ";
			
			genome += Bestgenome[i] + " ";
		}		
		System.out.println(genome);
	}

	/**
	 * Fonction qui permet de r�cup�rer le meilleur individu de la population
	 * @return le meilleur individu
	 */
	public Individu Best_individu(Population pop)
	{
		int index = 0;

		for(int i = 0; i < pop.GetPopulation().size(); i++)
		{
			if(pop.GetPopulation().get(i).GetPoids() > pop.GetPopulation().get(index).GetPoids())
				index = i;
		}
		return pop.GetPopulation().get(index);
	}
}
