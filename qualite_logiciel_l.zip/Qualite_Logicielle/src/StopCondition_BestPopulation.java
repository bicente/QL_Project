
public class StopCondition_BestPopulation implements  IStopCondition {
	
	int _nb_pop_iteration = 0;
	Population _pop;
	boolean first = false;
	
	@Override
	public  boolean stop_condition(Population pop, int nb_iteration)
	{
		if(first==true)
		{
			boolean flag = false;
			for(int i = 0; i < pop.GetPopulation().size(); i++ )
			{
				if(pop.GetPopulation().get(i) != _pop.GetPopulation().get(i))
				{
					_nb_pop_iteration = 0;
					flag = true;
					break;
				}
			}
			
			if (flag == false)
				_nb_pop_iteration+=1;
			else
				_pop.SetPopulation(pop.GetPopulation());
			
			if(_nb_pop_iteration >= nb_iteration)
				return true;
			else
				return false;
		}
		else
		{
			_pop = pop;
			first = true;
			return false;
		}
	}

}
