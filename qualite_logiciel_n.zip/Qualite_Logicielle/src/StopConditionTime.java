
public class StopConditionTime implements  IStopCondition {
	
	@Override
	/**
	 * Arr�t apr�s un nombre donn� d'it�rations
	 * @return vrai si nombre iteration r�aliser sinon retourn faux
	 */
	public boolean stop_condition(long time, int  partie_int)
{
		
		long lo = System.nanoTime();
		
		long timer =time +time/partie_int;
		if(lo > timer)
			return true;
		else
			return false;
	}
}
