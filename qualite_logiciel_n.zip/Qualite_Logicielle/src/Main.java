import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		List<String> list_condition_arret = new ArrayList<>();
		
		list_condition_arret.add("X iterations");
		
		
		Algorithm al = new Algorithm("F(x,y)=(x+2*y-7)^2+(2*x+y-5)^2", 2, -10, 10,20,100,"Best individu",list_condition_arret,"Tournament");
	}
}
